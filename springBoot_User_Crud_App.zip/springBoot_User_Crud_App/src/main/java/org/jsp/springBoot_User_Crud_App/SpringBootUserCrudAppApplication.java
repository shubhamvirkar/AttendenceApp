package org.jsp.springBoot_User_Crud_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserCrudAppApplication.class, args);
	}

}
