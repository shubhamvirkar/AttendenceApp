package org.jsp.springBoot_User_Crud_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
