package spring_ioc._usid_crud_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIocUsidCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringIocUsidCrudAppApplication.class, args);
	}

}
