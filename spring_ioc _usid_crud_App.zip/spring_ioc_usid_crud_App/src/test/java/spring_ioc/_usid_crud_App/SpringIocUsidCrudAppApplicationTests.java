package spring_ioc._usid_crud_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocUsidCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
