package com.Jforce.Attendance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Jforce.Attendance.entity.Attendance;
import com.Jforce.Attendance.entity.User;
import com.Jforce.Attendance.service.AttendanceService;
import com.Jforce.Attendance.service.UserService;

import jakarta.servlet.http.HttpSession;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class AttendenceController {
    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private UserService userService;

    @PostMapping("/present")
    public String signIn(@RequestParam("id") int id, HttpSession session, Model model) {
        System.out.println("Received ID: " + id);

        Optional<User> optionalUser = userService.findUserById(id);
        System.out.println(optionalUser.get());
        if (optionalUser.isEmpty()) {
            System.out.println("User not found with ID: " + id);
            session.setAttribute("msg", "User not found with ID: " + id);
            return "redirect:/error"; 
        }

        User user = optionalUser.get();
        System.out.println("User found: " + user);
        model.addAttribute("user", user);

        Attendance attendance = new Attendance();
        attendance.setUser(user);
        attendance.setSignInTime(LocalDateTime.now());
        attendanceService.save(attendance);
        
        return "dashboard";
    }


    @PostMapping("/leave")
    public String signOut(@RequestParam int id, Model model, HttpSession session ){
        Optional<Attendance> optionalAttendance = attendanceService.findByUserId(id).stream()
                .filter(a -> a.getSignOutTime() == null)
                .findFirst();

        if (optionalAttendance.isEmpty()) {
            System.out.println("No attendance record found for user with ID: " + id);
            // Handle the case where no attendance record is found
            session.setAttribute("msg", "Please sign in first");
            return "redirect:/error"; // Or whatever redirection or error handling you need
        }

        Attendance attendance = optionalAttendance.get();
        attendance.setSignOutTime(LocalDateTime.now());
        attendanceService.save(attendance);
        return "redirect:/login";
    }


    @GetMapping("/userReport")
    public String viewReport(@RequestParam int id, Model model) {
        List<Attendance> attendances= attendanceService.findByUserId(id);
        User user= userService.findUser(id); 
        model.addAttribute("attendances" , attendances);
        model.addAttribute("user", user);
        System.out.println(attendances);
        return "userReport";
    }
}

