package com.Jforce.Attendance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Jforce.Attendance.entity.Admin;
import com.Jforce.Attendance.repository.AdminRepo;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepo repo;
	
	public List<Admin> findAllAdmin(){
		return repo.findAll();
	}
}
