package com.Jforce.Attendance.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Jforce.Attendance.entity.Attendance;
import com.Jforce.Attendance.entity.User;
import com.Jforce.Attendance.repository.AttendanceRepo;

@Service
public class AttendanceService {

	@Autowired
	private AttendanceRepo repo;
	
	
	
	public List<Attendance> findUserAttendances(int id) {
        return repo.findByUserId(id);
    }

    public List<Attendance> findAllAttendances() {
        return repo.findAll();
    }

    

    public List<Attendance> findUserAttendance(int userId) {
        return  repo.findByUserId(userId);
    }

    public Attendance save(Attendance attendance) {
        return repo.save(attendance);
    }

    public List<Attendance> findByUserId(int userId) {
        return repo.findByUserId(userId);
    }

    
    public boolean isUserAlreadySignedIn(User user) {
        Optional<Attendance> activeAttendance = repo.findFirstByUserAndSignOutTimeIsNull(user);
        return activeAttendance.isPresent();
    }

//    public boolean hasUserAlreadySignedInToday(User user) {
//        LocalDate today = LocalDate.now();
//        Optional<Attendance> signinRecord = repo.findByUserAndSignInDate(user, today);
//        return signinRecord.isPresent();
//    }

    
    
    
    
    
}
