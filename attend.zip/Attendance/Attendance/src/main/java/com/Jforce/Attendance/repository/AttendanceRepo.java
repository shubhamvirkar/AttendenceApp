package com.Jforce.Attendance.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Jforce.Attendance.entity.Attendance;
import com.Jforce.Attendance.entity.User;

@Repository
public interface AttendanceRepo extends JpaRepository<Attendance, Integer>{

	List<Attendance> findByUserId(int Id);
	
	List<Attendance> findByUserIdAndSignInTimeBetween(int userId, LocalDateTime start, LocalDateTime end);
	
//    Optional<Attendance> findByUserAndSignInDate(User user, LocalDate signInDate);

	
    Optional<Attendance> findFirstByUserAndSignOutTimeIsNull(User user);

	

    
	
}
