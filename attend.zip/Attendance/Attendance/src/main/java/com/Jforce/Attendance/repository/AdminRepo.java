package com.Jforce.Attendance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Jforce.Attendance.entity.Admin;
import com.Jforce.Attendance.entity.User;

@Repository
public interface AdminRepo extends JpaRepository<Admin, Integer>{
	
	
	
	

}
