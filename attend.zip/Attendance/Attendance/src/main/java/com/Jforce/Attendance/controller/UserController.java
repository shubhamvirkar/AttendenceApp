package com.Jforce.Attendance.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.Jforce.Attendance.entity.User;
import com.Jforce.Attendance.service.AttendanceService;
import com.Jforce.Attendance.service.UserService;

import jakarta.servlet.http.HttpSession;


@Controller
public class UserController {
	
	@Autowired
	private UserService uService;
	
	@Autowired
	private AttendanceService aService;
	
	

	@GetMapping("/")
	public String show(Model model) {
		model.addAttribute("user" , new User());
		return "index";
	}
	
	@GetMapping("/regUser")
    public String regUser(Model model) {
         model.addAttribute("user" , new User());
        return "regUser";
    }
	
	@PostMapping("/saveUser")
    public String saveUser(User user ,  HttpSession session) {
		if(user!=null ) {
			if(uService.checkEmail(user.getEmail()) || uService.checkUsername(user.getUsername())) {
				if(uService.checkEmail(user.getEmail()) && uService.checkUsername(user.getUsername())) {
					session.setAttribute("msg", "Email and Username Already Exists");
					return "error";
				}
				else if(uService.checkEmail(user.getEmail())) {
					session.setAttribute("msg", "Email  Already Exists");
					return "error";
				}
				else if(uService.checkUsername(user.getUsername())) {
					session.setAttribute("msg", "Username Already Exists");
					return "error";
				}
			}
		}
		
       uService.saveUser(user);
       session.setAttribute("user", user.getName());
        return "dashboard";
    }
	
	@GetMapping("/login")
	public String getUser(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}
	
	@PostMapping("/checkLogin")
	public String validateUser(User user, Model model, HttpSession session) {
		
		System.out.println(user);
		User check= user;
	
		for(User u : uService.getAllUser()) {
			if (u.getUsername().equals(check.getUsername()) && u.getPassword().equals(check.getPassword())) {
				
		check= uService.findUserByUsername(user.getUsername());
				 session.setAttribute("user" ,check);
				 model.addAttribute("user", check);
				return "dashboard";
			}
		}
		System.out.println(user);
		session.setAttribute("msg", "Invalid Username Or Password");
		return "error";
	
	}
	

	
























}