package com.Jforce.Attendance.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Jforce.Attendance.entity.User;
import com.Jforce.Attendance.repository.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo repo;

	public User saveUser(User user) {
		return repo.save(user);
		
	}
	
	public User findUserByUsername(String Username) {
		return repo.findByUsername(Username);
	}
	
	
	public List<User> getAllUser(){
		return repo.findAll();
	}
	
	
	public User findUser(int id) {
		return repo.findById(id).get();
	}
	
	public boolean checkEmail(String email) {
		return repo.existsByEmail(email);
	}
	
	public boolean checkUsername(String username) {
		return repo.existsByUsername(username);
	}

	public Optional<User> findUserById(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}
	
	
}
