package com.Jforce.Attendance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Jforce.Attendance.entity.Admin;
import com.Jforce.Attendance.entity.Attendance;
import com.Jforce.Attendance.entity.User;
import com.Jforce.Attendance.service.AdminService;
import com.Jforce.Attendance.service.AttendanceService;
import com.Jforce.Attendance.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

	@Autowired
	private AdminService service;
	
	@Autowired
	private AttendanceService attendanceService;
	
	@Autowired UserService userService ;
	
	@GetMapping("/admin")
	public String getAdmin(Model model) {
		model.addAttribute("admin", new Admin());
		return "admin";
	}
	
	@PostMapping("/checkAdmin")
	public String validateAdmin(Admin admin, Model model, HttpSession session) {
		
		for(Admin a: service.findAllAdmin()) {
			if(a.getPassword().equals(admin.getPassword()) && a.getUsername().equals(admin.getUsername())) {
				admin=a;
				System.out.println(a + " a ");
				System.out.println(admin + " admin ");
				model.addAttribute("users", userService.getAllUser());
				model.addAttribute("admin", admin);
//				  List<Attendance> attendances= attendanceService.findByUserId(id);
				return "adminDashboard";
			}
		}
		session.setAttribute("msg", "This is not admin check and try again");
		return "error";
	}
	
	
	@GetMapping("/adminReport")
    public String viewReport(@RequestParam int id, Model model) {
        List<Attendance> attendances= attendanceService.findByUserId(id);
        User user= userService.findUser(id); 
        model.addAttribute("attendances" , attendances);
        model.addAttribute("user", user);
        System.out.println(attendances);
        return "adminReport";
    }
	
}
